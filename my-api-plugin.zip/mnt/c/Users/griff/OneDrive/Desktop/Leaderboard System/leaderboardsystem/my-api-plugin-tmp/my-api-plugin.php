<?php
/*
Plugin Name: My API Plugin
Version: 1.0.0
Author: Your Name
Author URI: https://example.com
*/

// Plugin code goes here...

// Shortcode callback for account creation view
function create_account_shortcode_callback($atts) {
    ob_start();
    include(plugin_dir_path(__FILE__) . 'templates/create-account.php');
    return ob_get_clean();
}
add_shortcode('create-account', 'create_account_shortcode_callback');

// Shortcode callback for account information view
function account_information_shortcode_callback($atts) {
    ob_start();
    include(plugin_dir_path(__FILE__) . 'templates/account-information.php');
    return ob_get_clean();
}
add_shortcode('account-information', 'account_information_shortcode_callback');
